# pytest-clickhouse

[![PyPI - Version](https://img.shields.io/pypi/v/pytest-clickhouse.svg)](https://pypi.org/project/pytest-clickhouse)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pytest-clickhouse.svg)](https://pypi.org/project/pytest-clickhouse)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install pytest-clickhouse
```

## License

`pytest-clickhouse` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
